#ifndef IMPORTS_H
#define IMPORTS_H

#include "..\..\..\x64_dbg_bridge\bridgemain.h"
#include "..\..\..\x64_dbg_dbg\_dbgfunctions.h"

#endif // IMPORTS_H
