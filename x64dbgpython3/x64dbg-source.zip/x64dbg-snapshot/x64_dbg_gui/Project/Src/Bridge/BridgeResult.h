#ifndef BRIDGERESULT_H
#define BRIDGERESULT_H

#include "NewTypes.h"

class BridgeResult
{
public:
    BridgeResult();
    ~BridgeResult();
    int_t Wait();
};

#endif // BRIDGERESULT_H
