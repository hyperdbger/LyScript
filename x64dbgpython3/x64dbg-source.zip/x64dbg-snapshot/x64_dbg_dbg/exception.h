#pragma once

void ExceptionCodeInit();
const char* ExceptionCodeToName(unsigned int ExceptionCode);