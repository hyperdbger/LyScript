#pragma once

void ErrorCodeInit();
const char* ErrorCodeToName(unsigned int ErrorCode);