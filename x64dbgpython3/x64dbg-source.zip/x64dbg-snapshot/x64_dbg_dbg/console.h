#pragma once

#include "_global.h"

void dputs(const char* Text);
void dprintf(const char* Format, ...);
void dprintf_args(const char* Format, va_list Args);