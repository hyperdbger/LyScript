#pragma once

#include "_global.h"

void Analyse_nukem(uint base, uint size);