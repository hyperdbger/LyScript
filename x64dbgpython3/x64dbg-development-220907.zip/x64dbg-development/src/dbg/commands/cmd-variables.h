#pragma once

#include "command.h"

bool cbInstrVar(int argc, char* argv[]);
bool cbInstrVarDel(int argc, char* argv[]);
bool cbInstrVarList(int argc, char* argv[]);
