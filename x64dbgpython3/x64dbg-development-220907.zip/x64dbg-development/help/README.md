This help has been moved.

Web help: http://help.x64dbg.com
Github: https://github.com/x64dbg/docs
Read the Docs: https://readthedocs.org/projects/x64dbg